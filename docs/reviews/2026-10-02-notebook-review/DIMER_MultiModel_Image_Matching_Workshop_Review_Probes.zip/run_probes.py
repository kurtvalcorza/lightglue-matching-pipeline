"""Review probes for tutorials/DIMER_MultiModel_Image_Matching_Workshop.ipynb (MAT review, 2026-10-02).

Evidence basis: DIRECT EXECUTION on a CPU workstation (Windows, Python 3.13, CUDA_VISIBLE_DEVICES=-1) of the
notebook's own code cells, top to bottom, plus static source checks. The two matchers are STAND-INS: the
isolated vismatch environment is not built (subprocess calls in the environment cell are faked) and the
matcher runner is replaced by a deterministic stand-in that warps random points through the recorded reference
homography with model-specific noise and 10% outliers. Photos, the pair generator, the split, the geometric
evaluator, both model-neutral baselines, the freeze, the exports and the report bundle are the notebook's real
code on real inputs (the 360 pinned iNaturalist photos for the default path; synthetic textured photos for BYOD).
Nothing here is evidence about the real LightGlue/XoFTR models, a GPU, or Google Colab.

Usage: python run_probes.py <notebook.ipynb> <workdir> <results.json> [--skip-default]
"""
from __future__ import annotations

import contextlib
import hashlib
import io
import json
import os
import re
import subprocess
import sys
import time
import traceback
import zipfile
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402
import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402

NB = Path(sys.argv[1]).resolve()
WORK = Path(sys.argv[2]).resolve()
OUT = Path(sys.argv[3]).resolve()
SKIP_DEFAULT = "--skip-default" in sys.argv
WORK.mkdir(parents=True, exist_ok=True)

NOTEBOOK = json.loads(NB.read_text(encoding="utf-8"))
CELLS = NOTEBOOK["cells"]
CODE = ["".join(c["source"]) for c in CELLS if c["cell_type"] == "code"]
MD = ["".join(c["source"]) for c in CELLS if c["cell_type"] == "markdown"]
RESULTS: dict = {"notebook": str(NB), "notebook_sha256": hashlib.sha256(NB.read_bytes()).hexdigest(),
                 "environment": {"python": sys.version.split()[0], "platform": sys.platform,
                                 "CUDA_VISIBLE_DEVICES": os.environ.get("CUDA_VISIBLE_DEVICES")},
                 "evidence_basis": "direct CPU execution with stand-in matchers + source inspection", "probes": {}}


def save():
    OUT.write_text(json.dumps(RESULTS, indent=2, default=str), encoding="utf-8")


def title(src: str) -> str:
    m = re.match(r"# @title (.*)", src)
    return m.group(1).strip() if m else src.splitlines()[0][:60]


def display(obj=None, *args, **kwargs):
    if hasattr(obj, "to_string"):
        print(obj.to_string())
    else:
        print(obj)


# ---------------------------------------------------------------- stand-in matcher runner
def stand_in_runner(model, pairs_path, out_dir, meta_path):
    pairs = json.loads(Path(pairs_path).read_text(encoding="utf-8"))
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    sigma = {"lightglue": 0.6, "xoftr": 1.2}[model]
    counts = []
    for row in pairs:
        seed = int(hashlib.sha256((model + row["pair_id"]).encode()).hexdigest()[:8], 16)
        rng = np.random.default_rng(seed)
        with Image.open(row["image0"]) as im:
            w, h = im.size
        if "homography" in row:
            H = np.asarray(row["homography"], float)
            n = 300 if model == "lightglue" else 900
            k0 = np.c_[rng.uniform(0, w - 1, n), rng.uniform(0, h - 1, n)]
            hom = np.c_[k0, np.ones(n)] @ H.T
            k1 = hom[:, :2] / hom[:, 2:3] + rng.normal(0, sigma, (n, 2))
            keep = (k1[:, 0] >= 0) & (k1[:, 0] < w) & (k1[:, 1] >= 0) & (k1[:, 1] < h)
            k0, k1 = k0[keep], k1[keep]
            bad = rng.random(len(k0)) < 0.1
            k1[bad] = np.c_[rng.uniform(0, w - 1, bad.sum()), rng.uniform(0, h - 1, bad.sum())]
        else:
            k0 = rng.uniform(0, min(w, h) - 41, (20, 2))
            k1 = k0 + np.array([40.0, 25.0])
        np.savez_compressed(out / f"{row['pair_id']}.npz", kpts0=k0.astype(np.float32),
                            kpts1=k1.astype(np.float32), confidence=np.ones(len(k0), np.float32))
        counts.append(len(k0))
    meta = {"model": model, "backend_name": "STAND-IN", "execution_backend": "stand-in (review probe)",
            "vismatch_version": "not-used", "python": sys.version.split()[0], "torch": "not-used",
            "device": "cpu", "pairs": len(pairs), "load_seconds": 0.0, "inference_seconds": 0.0,
            "seconds_per_pair": 0.0, "matches_per_pair_raw": float(np.mean(counts)) if counts else 0.0,
            "peak_cuda_bytes": None, "verified_assets_consumed": [], "dimer_asset_parity_observations": {}}
    Path(meta_path).write_text(json.dumps(meta, indent=2), encoding="utf-8")


ENV_CALLS: list = []


def fake_subprocess_run(cmd, *args, **kwargs):
    parts = [str(p) for p in cmd]
    ENV_CALLS.append(parts)
    if "venv" in parts:
        root = Path(parts[-1])
        for exe in (root / "Scripts" / "python.exe", root / "bin" / "python"):
            exe.parent.mkdir(parents=True, exist_ok=True)
            exe.write_text("stand-in", encoding="utf-8")
    return subprocess.CompletedProcess(parts, 0, "", "")


def tree_digest(root: Path) -> dict:
    root = Path(root)
    if not root.exists():
        return {}
    return {str(p.relative_to(root)).replace("\\", "/"): hashlib.sha256(p.read_bytes()).hexdigest()
            for p in sorted(root.rglob("*")) if p.is_file()}


def set_controls(src: str, controls: dict) -> str:
    for name, value in controls.items():
        pattern = re.compile(rf"^({re.escape(name)}\s*=\s*)(.*?)(\s*# @param.*)$", re.M)
        if not pattern.search(src):
            raise KeyError(f"control {name} not found (EXE6)")
        src = pattern.sub(lambda m: m.group(1) + repr(value) + m.group(3), src, count=1)
    return src


def run_notebook(run_dir: Path, controls: dict | None = None, ns: dict | None = None, label: str = "run"):
    """Execute every code cell in order inside run_dir. Returns (ns, record)."""
    controls = controls or {}
    run_dir.mkdir(parents=True, exist_ok=True)
    ns = ns if ns is not None else {"__name__": "__main__", "display": display}
    record = {"label": label, "controls": controls, "cells": [], "completed": False, "error": None}
    old_cwd = os.getcwd()
    os.chdir(run_dir)
    plt.show = lambda *a, **k: plt.close("all")
    started = time.perf_counter()
    try:
        for src in CODE:
            t = title(src)
            if t == "Notebook controls":
                src = set_controls(src, controls)
            buf = io.StringIO()
            before = None
            if "RUN_TOLERANCE_ACTIVITY" in src and t != "Notebook controls":
                before = tree_digest(Path(ns.get("OUTPUT_DIR", "outputs")))
            cell_started = time.perf_counter()
            try:
                with contextlib.redirect_stdout(buf):
                    if t == "Create isolated vismatch environment":
                        real = subprocess.run
                        subprocess.run = fake_subprocess_run
                        n_before = len(ENV_CALLS)
                        try:
                            exec(compile(src, t, "exec"), ns)
                        finally:
                            subprocess.run = real
                        record["env_root"] = str(Path(ns["ENV_ROOT"]).resolve())
                        record["env_build_invoked"] = any("venv" in c for c in ENV_CALLS[n_before:])
                        original = ns["run_checked"]

                        def run_checked(cmd, label_, _orig=original, _ns=ns):
                            parts = [str(p) for p in cmd]
                            if any(p.endswith("run_matcher.py") for p in parts):
                                arg = lambda k: parts[parts.index(k) + 1]  # noqa: E731
                                stand_in_runner(arg("--model"), arg("--pairs"), arg("--out-dir"), arg("--metadata"))
                                return subprocess.CompletedProcess(parts, 0, "", "")
                            return _orig(cmd, label_)

                        ns["run_checked"] = run_checked
                    else:
                        exec(compile(src, t, "exec"), ns)
            except Exception as exc:  # record and stop, as Run all would
                record["cells"].append({"title": t, "ok": False, "stdout_tail": buf.getvalue()[-1500:]})
                record["error"] = {"cell": t, "type": type(exc).__name__, "message": str(exc)[:500],
                                   "traceback_tail": traceback.format_exc()[-1200:]}
                return ns, record
            entry = {"title": t, "ok": True, "seconds": round(time.perf_counter() - cell_started, 2),
                     "stdout_tail": buf.getvalue()[-2500:]}
            if before is not None:
                entry["output_tree_unchanged"] = before == tree_digest(Path(ns.get("OUTPUT_DIR", "outputs")))
            record["cells"].append(entry)
        record["completed"] = True
    finally:
        os.chdir(old_cwd)
        record["seconds"] = round(time.perf_counter() - started, 1)
    return ns, record


def make_photos(root: Path, n: int, size=(320, 240), seed=0):
    root.mkdir(parents=True, exist_ok=True)
    rng = np.random.default_rng(seed)
    for i in range(n):
        base = rng.integers(0, 255, (size[1] // 8, size[0] // 8, 3), dtype=np.uint8)
        Image.fromarray(base).resize(size, Image.BICUBIC).save(root / f"photo_{i:03d}.png")
    return root


def bundle_members(ns, run_dir):
    for line in ns.get("_bundle_line", []):
        pass
    zips = sorted(Path(run_dir).rglob("*_DIMER_Image_Matching_Workshop_Report.zip"), key=lambda p: p.stat().st_mtime)
    return zips


# ======================================================================== static probes
def md_text():
    return "\n\n".join(MD)


def static_probes():
    text = md_text()
    code_text = "\n\n".join(CODE)
    first_val_scoring = next(i for i, c in enumerate(CELLS)
                             if c["cell_type"] == "code" and "Common validation scoring" in "".join(c["source"]))
    md_before_scoring = "\n".join("".join(c["source"]) for c in CELLS[:first_val_scoring] if c["cell_type"] == "markdown")
    md_after_scoring = ["".join(c["source"]) for c in CELLS[first_val_scoring:] if c["cell_type"] == "markdown"]
    sec18 = next(("".join(c["source"]) for c in CELLS if c["cell_type"] == "markdown"
                  and "Match density and runtime" in "".join(c["source"])), "")
    controls = next(c for c in CODE if title(c) == "Notebook controls")
    controls_idx = next(i for i, c in enumerate(CELLS) if "".join(c["source"]) == controls)
    md_upto_controls = "\n".join("".join(c["source"]) for c in CELLS[:controls_idx + 1])
    headings = [line for m in MD for line in m.splitlines() if re.match(r"#+ \d+\. ", line)]
    ts = [m for m in MD if re.search(r"^#+ (\d+\. )?Troubleshooting", m, re.M)]
    p = RESULTS["probes"]
    p["P05_metric_and_result_guidance"] = {
        "defines_homography_accuracy_before_first_scored_table": bool(re.search(r"homography[ _]acc[^\n]*corner|corner[^\n]*homography[ _]acc", md_before_scoring, re.I)),
        "defines_matches_and_inliers_per_pair_before_first_scored_table": bool(re.search(r"inliers_per_pair|inliers per pair", md_before_scoring, re.I)),
        "explains_ransac_dlt_before_section_8_code": bool(re.search(r"RANSAC[^\n]*(random|robust)", md_before_scoring, re.I)),
        "what_to_notice_notes_after_validation_scoring": sum("What to notice" in m for m in md_after_scoring),
        "section18_labelled_infrastructure": "Infrastructure" in sec18,
        "raw_json_dump_truncated_at_5000": "[:5000]" in code_text,
        "disagreement_tables_labelled": bool(re.search(r"print\([^)]*(LightGlue|lightglue)[^)]*(better|advantage|ahead)", code_text, re.I)),
    }
    p["P06_orientation"] = {
        "learning_objectives_heading": bool(re.search(r"^#+ .*Learning objectives", text, re.M | re.I)),
        "template_phrases": [s for s in ("where applicable", "where the capability supports them", "model or model comparison",
                                         "errors, disagreements, robustness, or resource tradeoffs") if s in text],
    }
    p["P07_information_architecture"] = {
        "troubleshooting_sections": len(ts),
        "generic_template_rows": [s for s in ("release/unload steps", "labels, or limits", "Too many large models") if s in text],
        "numbered_headings_not_level2": [h for h in headings if not h.startswith("## ")],
        "section21_promises_optional_adaptation": "Optional model-native adaptation" in text,
    }
    p["P08_activity"] = {
        "executable_activity_cell": any("RUN_TOLERANCE_ACTIVITY" in c and title(c) != "Notebook controls" for c in CODE),
        "activity_control_default_off": bool(re.search(r"^RUN_TOLERANCE_ACTIVITY\s*=\s*False\s*# @param", controls, re.M)),
        "activity_answer_given_in_prompt": "cannot increase the fraction" in text,
        "exercise_sample_answers": text.count("<summary>"),
    }
    p["P09_runtime_statement"] = {
        "opening_states_download_sizes": bool(re.search(r"\d+(\.\d+)?\s*(MB|MiB|GB)", "\n".join(MD[:2]))),
        "opening_states_measured_t4_timing": bool(re.search(r"s per pair|s/pair", "\n".join(MD[:2]))),
        "cpu_warning_in_code": bool(re.search(r"No (CUDA|GPU)", code_text)),
    }
    p["P04_byod_contract_static"] = {
        "limits_stated_by_controls_cell": all(s in md_upto_controls for s in ("360", "4096")),
        "independence_assumption_stated": bool(re.search(r"independent", text, re.I) and re.search(r"random split|randomly split", text, re.I)),
        "upload_branch_checks_suffix": bool(re.search(r"name\.lower\(\)\.endswith|Path\(name\)\.suffix", next(c for c in CODE if title(c).startswith("Acquire")))),
    }
    p["P03_env_root_static"] = {
        "env_root_depends_on_per_run_work_root": bool(re.search(r"ENV_ROOT\s*=\s*WORK_ROOT", code_text)),
    }
    save()


# ======================================================================== execution probes
def byod_probe():
    out = {}
    for n in (4, 8, 12, 13, 15):
        run_dir = WORK / f"byod_n{n}"
        photos = make_photos(run_dir / "user_photos", n, seed=n)
        _, rec = run_notebook(run_dir, {"USE_BYOD": True, "BYOD_PATH": str(photos)}, label=f"byod_n{n}")
        out[f"n={n}"] = {"completed": rec["completed"], "error": rec["error"], "seconds": rec["seconds"],
                         "failed_cell": rec["error"]["cell"] if rec["error"] else None,
                         "cells_ok": sum(c["ok"] for c in rec["cells"]), "cells_total": len(CODE)}
        RESULTS["probes"]["P01_byod_small_sets"] = out
        save()


def byod_messages_probe():
    run_dir = WORK / "byod_messages"
    run_dir.mkdir(parents=True, exist_ok=True)
    ns = {"__name__": "__main__", "display": display}
    os.chdir(run_dir)
    try:
        with contextlib.redirect_stdout(io.StringIO()):
            exec(compile(set_controls(CODE[0], {}), "controls", "exec"), ns)
            acquire = next(c for c in CODE if title(c).startswith("Acquire"))
            import ast
            mod = ast.parse(acquire)
            mod.body = [n for n in mod.body if isinstance(n, (ast.FunctionDef, ast.Import, ast.ImportFrom, ast.Assign))]
            exec(compile(mod, "acquire", "exec"), ns)
        msgs = {}

        def attempt(name, path):
            try:
                ns["load_byod_photos"](path)
                msgs[name] = "ACCEPTED"
            except Exception as exc:  # noqa: BLE001
                msgs[name] = f"{type(exc).__name__}: {exc}"

        attempt("three_photos", make_photos(run_dir / "three", 3))
        d = make_photos(run_dir / "dup", 5)
        with Image.open(d / "photo_000.png") as im:
            im.save(d / "copy_of_0.png", compress_level=0)
        attempt("duplicate", d)
        t = make_photos(run_dir / "tiny", 5)
        Image.new("RGB", (10, 40)).save(t / "tiny_one.png")
        attempt("tiny", t)
        fake_zip = run_dir / "uploaded-byod.zip"
        fake_zip.write_bytes((d / "photo_001.png").read_bytes())
        attempt("png_bytes_named_zip", fake_zip)
        RESULTS["probes"]["P04_byod_messages"] = {
            "messages": msgs,
            "count_message_names_found_count": bool(re.search(r"\b3\b", msgs["three_photos"])),
            "duplicate_message_names_files": "copy_of_0" in msgs["duplicate"] or "photo_000" in msgs["duplicate"],
            "tiny_message_names_file": "tiny_one" in msgs["tiny"],
            "non_zip_message_actionable": "BadZipFile" not in msgs["png_bytes_named_zip"],
        }
    finally:
        os.chdir(WORK)
    save()


def default_and_sequence_probe():
    run_dir = WORK / "default"
    ns, rec = run_notebook(run_dir, {}, label="default")
    d = {"completed": rec["completed"], "error": rec["error"], "seconds": rec["seconds"], "env_root": rec.get("env_root")}
    if rec["completed"]:
        d["split"] = ns["split_report"]
        d["validation_pair_digest"] = ns["pairs_digest"](ns["validation_pair_rows"])
        d["test_pair_digest"] = ns["pairs_digest"](ns["test_pair_rows"])
        d["test_baselines"] = {k: {m: round(v[m], 3) if isinstance(v[m], float) and np.isfinite(v[m]) else v[m]
                                   for m in ("precision_3px", "homography_acc_3px", "matches_per_pair")}
                               for k, v in ns["test_baselines"].items()}
        d["standin_test_models"] = {k: {m: round(v[m], 4) for m in ("precision_3px", "homography_acc_3px", "inliers_per_pair")}
                                    for k, v in ns["test_models"].items()}
        d["exports"] = {k: v for k, v in tree_digest(run_dir / "outputs").items()
                        if k.endswith(".csv") and not k.endswith("runtime.csv")}
        d["cpu_warning_printed"] = any(re.search(r"No (CUDA|GPU)", c.get("stdout_tail", "")) for c in rec["cells"])
        d["hosted_2026_09_26_test_hacc3"] = {"identity": 0.0, "patch_neighbour": 0.333}
    RESULTS["probes"]["P10_default_path"] = d
    save()
    if not rec["completed"]:
        return
    # Same runtime: BYOD run, then the default again (as a learner returning to the canonical path would).
    photos = make_photos(WORK / "seq_user_photos", 15, seed=99)
    ns, rec_b = run_notebook(run_dir, {"USE_BYOD": True, "BYOD_PATH": str(photos)}, ns=ns, label="seq_byod")
    ns, rec_c = run_notebook(run_dir, {"USE_BYOD": False, "BYOD_PATH": "", "RUN_PATCH_BASELINE": False}, ns=ns, label="seq_default_again")
    canonical_zip = run_dir / "outputs_DIMER_Image_Matching_Workshop_Report.zip"
    members = zipfile.ZipFile(canonical_zip).namelist() if canonical_zip.exists() else []
    byod_zips = sorted((run_dir / "outputs" / "byod").glob("*_DIMER_Image_Matching_Workshop_Report.zip"))
    byod_members = zipfile.ZipFile(byod_zips[-1]).namelist() if byod_zips else []
    RESULTS["probes"]["P02_P03_sequence"] = {
        "byod_completed": rec_b["completed"], "byod_error": rec_b["error"],
        "default_again_completed": rec_c["completed"], "default_again_error": rec_c["error"],
        "canonical_bundle_members_under_byod": [m for m in members if m.replace("\\", "/").startswith("byod/")][:12],
        "canonical_bundle_byod_member_count": sum(m.replace("\\", "/").startswith("byod/") for m in members),
        "byod_bundle_member_count": len(byod_members),
        "env_root_default": rec.get("env_root"), "env_root_byod": rec_b.get("env_root"),
        "byod_run_rebuilds_model_environment": rec_b.get("env_build_invoked"),
        "activity_cells": [c for c in rec_c["cells"] if "output_tree_unchanged" in c],
    }
    save()


def activity_probe():
    """Run the BYOD n=15 path once more with the optional activity switched on (if the notebook has one)."""
    controls = next(c for c in CODE if title(c) == "Notebook controls")
    if "RUN_TOLERANCE_ACTIVITY" not in controls:
        RESULTS["probes"]["P08_activity_execution"] = {"status": "no activity control in this revision"}
        save()
        return
    run_dir = WORK / "activity_on"
    photos = make_photos(run_dir / "user_photos", 15, seed=15)
    _, rec = run_notebook(run_dir, {"USE_BYOD": True, "BYOD_PATH": str(photos), "RUN_TOLERANCE_ACTIVITY": True}, label="activity_on")
    act = [c for c in rec["cells"] if "output_tree_unchanged" in c]
    RESULTS["probes"]["P08_activity_execution"] = {"completed": rec["completed"], "error": rec["error"],
                                                   "activity_cells": act}
    save()


if __name__ == "__main__":
    static_probes()
    byod_messages_probe()
    byod_probe()
    activity_probe()
    if not SKIP_DEFAULT:
        default_and_sequence_probe()
    RESULTS["finished"] = True
    save()
    print(json.dumps({k: (v if k != "P10_default_path" else {kk: vv for kk, vv in v.items() if kk != "exports"})
                      for k, v in RESULTS["probes"].items()}, indent=1, default=str)[:12000])
