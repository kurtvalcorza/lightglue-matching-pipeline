"""Probes for the LGC review of tutorials/lightglue_matching_colab.ipynb (lightglue-matching-pipeline @ b3ea5f3).

CPU-only direct execution against the repository package (the notebook carries it verbatim; parity checked in P01).
Environment: an existing sibling-repo venv used read-only (detr-detection-pipeline/.venv): Python 3.12.12, torch 2.14.0+cpu,
torchvision 0.29.0+cpu, numpy 2.5.3, Pillow 11.3.0, safetensors 0.8.0 (= the inline PINS). Real converted weights are copied (read-only source: the local clone) into a scratch
weights dir together with the notebook's inline MANIFEST. Small inputs; not a Colab run.
Usage: python run_probes.py <worktree> <weights_src> <photo_cache> <outdir>
"""
import io
import json
import os
import random
import shutil
import subprocess
import sys
import time
import zipfile
from pathlib import Path

WT, WSRC, PHOTOS, OUT = (Path(a) for a in sys.argv[1:5])
OUT.mkdir(parents=True, exist_ok=True)
sys.path.insert(0, str(WT / 'src'))
results = {}


def record(pid, **kw):
    results[pid] = kw
    (OUT / 'results.json').write_text(json.dumps(results, indent=1, default=str), encoding='utf-8')
    print(pid, json.dumps(kw, default=str)[:700], flush=True)


# P01 static: blob, parse, compile, generator check, validator
nb_path = WT / 'tutorials/lightglue_matching_colab.ipynb'
blob = subprocess.run(['git', '-C', str(WT), 'rev-parse', 'HEAD:tutorials/lightglue_matching_colab.ipynb'], capture_output=True, text=True).stdout.strip()
nb = json.loads(nb_path.read_text(encoding='utf-8'))
chk = subprocess.run([sys.executable, 'tools/build_notebook.py', '--check'], cwd=WT, capture_output=True, text=True)
val = subprocess.run([sys.executable, 'tools/validate_release_assets.py'], cwd=WT, capture_output=True, text=True)
code_cells = [c for c in nb['cells'] if c['cell_type'] == 'code']
compiled = 0
for c in code_cells:
    compile(''.join(c['source']), '<cell>', 'exec')
    compiled += 1
record('P01_static', blob=blob, cells=len(nb['cells']), code_cells=len(code_cells), compiled=compiled,
       declared_spec=nb['metadata']['dimer'].get('notebook_spec'), build_check_rc=chk.returncode,
       build_check_tail=(chk.stdout + chk.stderr)[-300:], validator_rc=val.returncode,
       validator_tail=(val.stdout + val.stderr)[-400:])

from lightglue_pipeline import samples as S  # noqa: E402
import numpy as np  # noqa: E402
from PIL import Image  # noqa: E402


def textured(i, w=320, h=240):
    rng = np.random.default_rng(i)
    a = (rng.random((h // 8, w // 8, 3)) * 255).astype('uint8')
    return Image.fromarray(a).resize((w, h), Image.NEAREST)


def make_zip(n, path, w=320, h=240, fmt='JPEG'):
    with zipfile.ZipFile(path, 'w') as z:
        for i in range(n):
            buf = io.BytesIO()
            textured(i, w, h).save(buf, fmt)
            z.writestr(f'img_{i:03d}.' + ('jpg' if fmt == 'JPEG' else 'png'), buf.getvalue())
    return path


# P02 BYOD minimum: the notebook path load_byod_dataset -> split_dataset(seed=42) -> validate_dataset per split
byod = {}
for n in (8, 12, 17, 18, 20, 23, 24, 30):
    zp = make_zip(n, OUT / f'byod_{n}.zip')
    try:
        sp = S.split_dataset(S.load_byod_dataset(zp), seed=42)
        sizes = {k: len(v) for k, v in sp.items()}
        try:
            for part in sp.values():
                S.validate_dataset(part)
            byod[n] = {'split': sizes, 'verdict': 'accepted'}
        except ValueError as exc:
            byod[n] = {'split': sizes, 'verdict': 'rejected at validate_dataset', 'message': str(exc)[:200]}
    except ValueError as exc:
        byod[n] = {'verdict': 'rejected at split_dataset', 'message': str(exc)[:200]}
    zp.unlink()
record('P02_byod_minimum', stated_minimum=8, results=byod,
       effective_minimum=min([n for n, r in byod.items() if r['verdict'] == 'accepted'], default=None))

# P03 BYOD invalid inputs and their messages
inv = {}
empty = OUT / 'empty.zip'
with zipfile.ZipFile(empty, 'w') as z:
    z.writestr('readme.txt', 'no images')
tar = OUT / 'photos.tar'
tar.write_bytes(b'not a zip')
for label, p in (('zip without images', empty), ('tar archive', tar)):
    try:
        S.load_byod_dataset(p)
        inv[label] = 'accepted'
    except ValueError as exc:
        inv[label] = 'rejected: ' + str(exc)[:200]
small = make_zip(30, OUT / 'small.zip', 40, 30, 'PNG')
try:
    sp = S.split_dataset(S.load_byod_dataset(small), seed=42)
    for part in sp.values():
        S.validate_dataset(part)
    inv['30 PNG of 40x30 px'] = {'accepted': True, 'pair_size': list(sp['train'][0]['image0'].size)}
except ValueError as exc:
    inv['30 PNG of 40x30 px'] = 'rejected: ' + str(exc)[:200]
for p in (empty, tar, small):
    p.unlink()
record('P03_byod_invalid', results=inv)

# P04 re-running Section 7 (documented optional experiments / BYOD re-run) starts from the adapted matcher
import torch  # noqa: E402
from lightglue_pipeline.model import MANIFEST_NAME  # noqa: E402
from lightglue_pipeline.pipeline import LightGluePipeline  # noqa: E402

wdir = OUT / 'weights' / 'lightglue-aliked'
wdir.mkdir(parents=True, exist_ok=True)
for f in ('aliked_lightglue.safetensors', 'aliked-n16.safetensors'):
    if not (wdir / f).exists():
        shutil.copy2(WSRC / f, wdir / f)
cell19 = ''.join(nb['cells'][19]['source'])
manifest_src = cell19[cell19.index('MANIFEST = ') + len('MANIFEST = '): cell19.index('\n\nif (MANIFEST')]
(wdir / MANIFEST_NAME).write_text(json.dumps(json.loads(manifest_src), indent=2), encoding='utf-8')
t0 = time.perf_counter()
pipe = LightGluePipeline.from_pretrained(weights_dir=wdir, device='cpu')
base = {k: v.clone() for k, v in pipe.matcher.state_dict().items()}
corpus = S.read_corpus(S.fetch_corpus(cache_dir=str(PHOTOS)))
pick = random.Random(0).sample(corpus, 12)
pairs = S.make_pairs([{**r, 'id': f'p{i:02d}'} for i, r in enumerate(pick)], seed=7)
train, valset = pairs[:8], pairs[8:12]


def maxdiff(state, names):
    return max(float((state[n] - base[n]).abs().max()) for n in names)


# run 1 stands in for the default Section 7 run (val=None keeps the final epoch so the weights certainly move)
r1 = pipe.adapt(train, None, epochs=2, lr=3e-4, batch_size=4, trainable_layers=2)
names2 = r1['trainable_names']
after1 = {k: v.clone() for k, v in pipe.matcher.state_dict().items()}
# run 2 = the documented experiment "set TRAINABLE_LAYERS = 4" re-run of Section 7 on the same pipe
r2 = pipe.adapt(train, valset, epochs=1, lr=1e-4, batch_size=4, trainable_layers=4)
fresh = LightGluePipeline.from_pretrained(weights_dir=wdir, device='cpu')
fresh_val = fresh.evaluate(valset)['precision_3px']
art = OUT / 'adapter4'
pipe.save_artifact(art)
man = json.loads((art / 'manifest.json').read_text(encoding='utf-8'))
reloaded = LightGluePipeline.from_artifact(art, weights_dir=wdir, device='cpu')
rel_state = reloaded.matcher.state_dict()
mem_state = pipe.matcher.state_dict()
reload_maxdiff = max(float((rel_state[k] - mem_state[k]).abs().max()) for k in mem_state)
record('P04_rerun_stacks', seconds=round(time.perf_counter() - t0, 1),
       run1={'trainable_layers': 2, 'best_epoch': r1['best_epoch'], 'max_abs_change_vs_base': maxdiff(after1, names2)},
       run2={'trainable_layers': 4, 'epoch0_note': r2['history'][0].get('note'),
             'epoch0_val_precision_3px': r2['history'][0]['val']['precision_3px'],
             'true_frozen_val_precision_3px': fresh_val,
             'best_epoch': r2['best_epoch']},
       artifact_manifest={'trainable_layers': man['adapter']['trainable_layers'], 'epochs': man['adapter']['epochs'],
                          'n_train': man['adapter']['n_train'], 'history_epochs': [h['epoch'] for h in man['history']],
                          'history_epoch0_note': man['history'][0].get('note'),
                          'mentions_prior_adaptation': any(w in json.dumps(man).lower() for w in ('prior', 'stack', 'previous'))},
       reload_vs_memory_max_abs_diff=reload_maxdiff)
shutil.rmtree(OUT / 'weights', ignore_errors=True)
shutil.rmtree(art, ignore_errors=True)
print('done', flush=True)
